import define1 from "./a33468b95d0b15b0@817.js";

function _alcohol_abuse_by_state(FileAttachment){return(
FileAttachment("alcohol_abuse_by_state.json").json()
)}

function _us1(FileAttachment){return(
FileAttachment("us@1.json").json()
)}

function _alcohol_data(FileAttachment){return(
FileAttachment("alcohol_abuse_by_state.json").json()
)}

function _chart2(alcohol_data,d3,topojson,us1)
{
  const width = 975;
  const height = 610;

  // Helper: state name to FIPS code mapping (2-digit numeric string)
  const nameToFips = new Map(Object.entries({
    "Alabama": "01", "Alaska": "02", "Arizona": "04", "Arkansas": "05", "California": "06",
    "Colorado": "08", "Connecticut": "09", "Delaware": "10", "Florida": "12", "Georgia": "13",
    "Hawaii": "15", "Idaho": "16", "Illinois": "17", "Indiana": "18", "Iowa": "19",
    "Kansas": "20", "Kentucky": "21", "Louisiana": "22", "Maine": "23", "Maryland": "24",
    "Massachusetts": "25", "Michigan": "26", "Minnesota": "27", "Mississippi": "28", "Missouri": "29",
    "Montana": "30", "Nebraska": "31", "Nevada": "32", "New Hampshire": "33", "New Jersey": "34",
    "New Mexico": "35", "New York": "36", "North Carolina": "37", "North Dakota": "38", "Ohio": "39",
    "Oklahoma": "40", "Oregon": "41", "Pennsylvania": "42", "Rhode Island": "44", "South Carolina": "45",
    "South Dakota": "46", "Tennessee": "47", "Texas": "48", "Utah": "49", "Vermont": "50",
    "Virginia": "51", "Washington": "53", "West Virginia": "54", "Wisconsin": "55", "Wyoming": "56"
  }));

  // Convert alcohol_data into a map keyed by FIPS code
  const data = new Map(
    alcohol_data.map(d => [nameToFips.get(d.state), +d["Alcohol Deaths Per Capita"]])
  );

  const color = d3.scaleSequential()
      .domain(d3.extent(Array.from(data.values())))
      .interpolator(d3.interpolateReds);

  const path = d3.geoPath();

  const svg = d3.create("svg")
      .attr("viewBox", [0, 0, width, height])
      .attr("width", width)
      .attr("height", height)
      .attr("style", "max-width: 100%; height: auto;");

  svg.append("path")
      .datum(topojson.mesh(us1, us1.objects.states))
      .attr("fill", "none")
      .attr("stroke", "#ccc")
      .attr("d", path);

  const state = svg.append("g")
      .attr("stroke", "#000")
    .selectAll("path")
    .data(topojson.feature(us1, us1.objects.states).features)
    .join("path")
      .attr("fill", d => {
        const value = data.get(d.id);
        return value != null ? color(value) : "#eee";
      })
      .attr("d", path)
    .append("title")
      .text(d => {
        const value = data.get(d.id);
        return `${d.properties.name}: ${value != null ? value : "No data"}`;
      });
  const legend = svg.append("g")
    .attr("transform", `translate(${width - 120}, 20)`);  // Top-right corner

// Define the legend keys (in this case, the domain of your color scale)
const keys = color.domain();  // Assuming `color` is your color scale

keys.forEach((key, i) => {
  const legendRow = legend.append("g")
    .attr("transform", `translate(0, ${i * 20})`);

  legendRow.append("rect")
    .attr("width", 15)
    .attr("height", 15)
    .attr("fill", color(key));

  legendRow.append("text")
    .attr("x", 20)
    .attr("y", 12)
    .text(key.toFixed(1))  // Display the key value
    .attr("font-size", "12px")
    .attr("fill", "#000");
});

return Object.assign(svg.node(), { scales: { color } });


  return svg.node();
}


export default function define(runtime, observer) {
  const main = runtime.module();
  function toString() { return this.url; }
  const fileAttachments = new Map([
    ["alcohol_abuse_by_state.json", {url: new URL("./files/dddc9768d687a7496f27b401147a2bf7be195dcd78eb087708af8d445949f33c9c3f9fa4bb6178e3aae20ff0c0f23474138d446dbc1ee3e1bcad1f9006bf9d4a.json", import.meta.url), mimeType: "application/json", toString}],
    ["us@1.json", {url: new URL("./files/a41c361eded75425ae053e6af98b7359f4c1785c347ac4c27873133e722c9b3fefd144af7ae54d73893138635e7eef3eace116cf45e5e6a6ee3cb9f693f462a9.json", import.meta.url), mimeType: "application/json", toString}]
  ]);
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer("alcohol_abuse_by_state")).define("alcohol_abuse_by_state", ["FileAttachment"], _alcohol_abuse_by_state);
  main.variable(observer("us1")).define("us1", ["FileAttachment"], _us1);
  main.variable(observer("alcohol_data")).define("alcohol_data", ["FileAttachment"], _alcohol_data);
  const child1 = runtime.module(define1);
  main.import("Legend", child1);
  main.variable(observer("chart2")).define("chart2", ["alcohol_data","d3","topojson","us1"], _chart2);
  return main;
}
