function _us(FileAttachment){return(
FileAttachment("us.json").json()
)}

function _nation(FileAttachment){return(
FileAttachment("nation.json").json()
)}

function _statemap(FileAttachment){return(
FileAttachment("statemap.json").json()
)}

function _countymap(FileAttachment){return(
FileAttachment("countymap.json").json()
)}

function _5(us){return(
us.objects.nation
)}

function _aggregated_witnesses_cleaned1(FileAttachment){return(
FileAttachment("aggregated_witnesses_cleaned (1).json").json()
)}

function _aggregated_witnesses(FileAttachment){return(
FileAttachment("aggregated_witnesses.json").json()
)}

function _chart5(aggregated_witnesses_cleaned1,d3,topojson,us)
{
  // Assuming 'aggregated_witnesses_cleaned1' is your updated data.
  const data = aggregated_witnesses_cleaned1;

  // Print invalid rows (missing or bad coordinates)
  console.log("Invalid rows (missing or bad coordinates):");
  console.log(data.filter(d => isNaN(+d.latitude) || isNaN(+d.longitude)));

  // Log some projected coordinates to debug
  data.slice(0, 5).forEach(d => {
    const projected = d3.geoAlbersUsa().scale(1300).translate([487.5, 305])([+d.longitude, +d.latitude]);
    console.log(d.city, d.latitude, d.longitude, projected);
  });

  // Radius scale based on Haunted Places Witness Count
  const radius = d3.scaleSqrt()
      .domain([0, d3.max(data, d => +d["Haunted Places Witness Count"])])
      .range([1, 15]); // Smaller max radius for visibility

  // Path and projection
  const path = d3.geoPath();
  const projection = d3.geoAlbersUsa().scale(1300).translate([487.5, 305]);

  // SVG setup
  const svg = d3.create("svg")
      .attr("width", 975)
      .attr("height", 610)
      .attr("viewBox", [0, 0, 975, 610])
      .attr("style", "width: 100%; height: auto; height: intrinsic;");

  // Draw US background
  svg.append("path")
      .datum(topojson.feature(us, us.objects.nation))
      .attr("fill", "#ddd")
      .attr("d", path);

  svg.append("path")
      .datum(topojson.mesh(us, us.objects.states, (a, b) => a !== b))
      .attr("fill", "none")
      .attr("stroke", "white")
      .attr("stroke-linejoin", "round")
      .attr("d", path);

  // Plot data points (witness counts)
  svg.append("g")
      .attr("fill", "steelblue")
      .attr("fill-opacity", 0.5)
      .attr("stroke", "#fff")
      .attr("stroke-width", 0.5)
    .selectAll("circle")
    .data(data)
    .join("circle")
      .attr("transform", d => {
        const coords = projection([+d.longitude, +d.latitude]);
        return coords ? `translate(${coords})` : null;
      })
      .attr("r", d => radius(+d["Haunted Places Witness Count"]))
    .append("title")
      .text(d => `${d.city}\n${d["Haunted Places Witness Count"]} witnesses`);

  return svg.node();
}


export default function define(runtime, observer) {
  const main = runtime.module();
  function toString() { return this.url; }
  const fileAttachments = new Map([
    ["aggregated_witnesses.json", {url: new URL("./files/de4b16039a0084ccaf2e984c1976ba6d2e4c0e8eab2c2058a41fe410eb7ad046ea2d0e46d48244b200bf1d1b0d095e90c42881d9e4059c74fe6efb7708113f49.json", import.meta.url), mimeType: "application/json", toString}],
    ["us.json", {url: new URL("./files/a41c361eded75425ae053e6af98b7359f4c1785c347ac4c27873133e722c9b3fefd144af7ae54d73893138635e7eef3eace116cf45e5e6a6ee3cb9f693f462a9.json", import.meta.url), mimeType: "application/json", toString}],
    ["nation.json", {url: new URL("./files/3751dbd5cea734a88c88e8b8f4217dde8b58f0fcd378a9aad2ccda8108aeb0f36d5006f14a2e411a94fe791717ff87299ab9759427a948319822304a90099eed.json", import.meta.url), mimeType: "application/json", toString}],
    ["statemap.json", {url: new URL("./files/d20b6bdd5e24aa76d55fa738bfcb07b2d60af0b5a13deddbbdc194491bb9eb6f82ec0c5c312ed3888ad0ad14188f55af04f221d749f06abd8fc6c1cdc0f37a70.json", import.meta.url), mimeType: "application/json", toString}],
    ["countymap.json", {url: new URL("./files/0d60e07fabc699ef5dfa41c55fa4eec0672b1f4b70e65ffac9c8008a41e91c59b00abdb1e715c0f50441ddd9f0a16c564a988cd7ba3ef1bca2f2a60654774ea1.json", import.meta.url), mimeType: "application/json", toString}],
    ["aggregated_witnesses_cleaned (1).json", {url: new URL("./files/f1a8d82ae627d4286d4e74628cf2ffb1551f84d9877d16e02c23fbf40757d4b1ce0f7d4c7cab68f7b5cd5396b1de7cd86bdb6074b8da421a518eb4cb25c2e56c.json", import.meta.url), mimeType: "application/json", toString}]
  ]);
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer("us")).define("us", ["FileAttachment"], _us);
  main.variable(observer("nation")).define("nation", ["FileAttachment"], _nation);
  main.variable(observer("statemap")).define("statemap", ["FileAttachment"], _statemap);
  main.variable(observer("countymap")).define("countymap", ["FileAttachment"], _countymap);
  main.variable(observer()).define(["us"], _5);
  main.variable(observer("aggregated_witnesses_cleaned1")).define("aggregated_witnesses_cleaned1", ["FileAttachment"], _aggregated_witnesses_cleaned1);
  main.variable(observer("aggregated_witnesses")).define("aggregated_witnesses", ["FileAttachment"], _aggregated_witnesses);
  main.variable(observer("chart5")).define("chart5", ["aggregated_witnesses_cleaned1","d3","topojson","us"], _chart5);
  return main;
}
