import define1 from "./a33468b95d0b15b0@817.js";

function _1(md){return(
md`DSCI 550 Bar Chart`
)}

function _apparition_counts_cleaned(FileAttachment){return(
FileAttachment("apparition_counts_cleaned.json").json()
)}

function _chart7(apparition_counts_cleaned,d3)
{
  // Specify the chart’s dimensions.
  const width = 1800;
  const height = 600;
  const marginTop = 10;
  const marginRight = 10;
  const marginBottom = 60;
  const marginLeft = 50;

  // Define the keys for the apparition types.
  const keys = ["Ghost", "Unknown", "Orb", "UAP"];

  // Assuming `data` is an array of objects where each object has 'year' and apparition types
  // Example: data = [{"year": 1906, "Ghost": 18, "Orb": 1, "UAP": 4, "Unknown": 5}, {...}, {...}]
  let data = apparition_counts_cleaned;  // Replace `yourJsonData` with your actual data source.

  // Exclude the last line in the data
  data = data.slice(0, -1);  // Removes the last element from the array

  // Stack the data by apparition types
  const series = d3.stack()
    .keys(keys)
    (data);

  // Create x-scale for the years (x-axis)
  const x = d3.scaleBand()
    .domain(data.map(d => d.year))  // Get years from the data dynamically
    .range([marginLeft, width - marginRight])
    .padding(0.1);

  // Create y-scale for the count (y-axis)
  const y = d3.scaleLinear()
    .domain([0, d3.max(series, s => d3.max(s, d => d[1]))]).nice()
    .range([height - marginBottom, marginTop]);

  // Define the color scale for each apparition type
  const color = d3.scaleOrdinal()
    .domain(keys)
    .range(d3.schemeCategory10);

  // Create the SVG container
  const svg = d3.create("svg")
    .attr("width", width)
    .attr("height", height)
    .attr("viewBox", [0, 0, width, height])
    .attr("style", "max-width: 100%; height: auto;");

  // Append the stacked bars for each series
  svg.append("g")
    .selectAll("g")
    .data(series)
    .join("g")
      .attr("fill", d => color(d.key))
    .selectAll("rect")
    .data(D => D.map(d => (d.key = D.key, d)))  // Bind data to the bars
    .join("rect")
      .attr("x", d => x(d.data.year))  // Position each bar based on the year
      .attr("y", d => y(d[1]))  // Position bars along the y-axis
      .attr("height", d => y(d[0]) - y(d[1]))  // Calculate the height of the stacked bars
      .attr("width", x.bandwidth())  // Set width of each bar
    .append("title")  // Add a tooltip to show the value of each bar
      .text(d => `${d.data.year} ${d.key}: ${d.data[d.key]}`);

  // Append the x-axis (years)
  svg.append("g")
    .attr("transform", `translate(0,${height - marginBottom})`)
    .call(d3.axisBottom(x).tickFormat(d3.format("d")))
    .selectAll("text")
      .attr("transform", "rotate(-45)")
      .style("text-anchor", "end");

  // Append the y-axis (count)
  svg.append("g")
    .attr("transform", `translate(${marginLeft},0)`)
    .call(d3.axisLeft(y).ticks(null, "s"))
    .call(g => g.select(".domain").remove());

  svg.append("text")
    .attr("text-anchor", "middle")
    .attr("x", (width) / 2)
    .attr("y", height - 5)
    .text("Year");

// Add y-axis label
  svg.append("text")
    .attr("text-anchor", "middle")
    .attr("transform", "rotate(-90)")
    .attr("x", -(height / 2))
    .attr("y", 15)
    .text("Apparition Count");
  
  const legend = svg.append("g")
    .attr("transform", `translate(${width - marginRight - 120}, ${marginTop})`);  // Top-right

keys.forEach((key, i) => {
  const legendRow = legend.append("g")
    .attr("transform", `translate(0, ${i * 20})`);

  legendRow.append("rect")
    .attr("width", 15)
    .attr("height", 15)
    .attr("fill", color(key));

  legendRow.append("text")
    .attr("x", 20)
    .attr("y", 12)
    .text(key)
    .attr("font-size", "12px")
    .attr("fill", "#000");
});


  // Return the chart along with the color scale
  return Object.assign(svg.node(), { scales: { color } });
}


export default function define(runtime, observer) {
  const main = runtime.module();
  function toString() { return this.url; }
  const fileAttachments = new Map([
    ["apparition_counts_cleaned.json", {url: new URL("./files/0891c5aa810c331073d520d556f88687ddb9363b9e85415f624b11fb301ad622630daf4779f73fc4c607fdab181ee8b359c0fa72fe6d5600e560f0ca79f4868d.json", import.meta.url), mimeType: "application/json", toString}]
  ]);
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer()).define(["md"], _1);
  main.variable(observer("apparition_counts_cleaned")).define("apparition_counts_cleaned", ["FileAttachment"], _apparition_counts_cleaned);
  const child1 = runtime.module(define1);
  main.import("legend", child1);
  main.variable(observer("chart7")).define("chart7", ["apparition_counts_cleaned","d3"], _chart7);
  return main;
}
